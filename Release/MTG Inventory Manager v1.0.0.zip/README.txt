Installation:
1. Unzip the fold in which this file is contained.
2. Run the MTG Inventory Manager v1.0.0.jar file.

That should be it.  Contact me if it's not working for you:
https://hades948.wixsite.com/tylerroyerportfolio/contact

NOTE: You will likely need a recent version of Java to run this program.
You can download the most recent version from Oracle https://www.java.com



This software is licensed under the GNU GPL 3.0 license.

This software uses resources from, but is not affiliated with
"Scryfall" and "Wizards of the Coast."

Copyright (C) 2020 Tyler Royer